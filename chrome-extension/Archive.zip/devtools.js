chrome.devtools.panels.create("ForerunnerDB",
	"icon.png",
	"panel.html",
	function (panel) {
		/*panel.createSidebarPane("SceneGraph",
			function(sidebar) {
				sidebar.setPage("sidebar.html");
				sidebar.setHeight("8ex");
			}
		);*/
	}
);